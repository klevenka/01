import random

def rdm(x):
    x = 5
    random.seed(x)
    delta = random.random()
    print(delta)
